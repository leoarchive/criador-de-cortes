# Criador de cortes

Se você deseja ganhar muito dinheiro com o conteúdo de terceiros e ao mesmo tempo compactuar com a disseminação de informações falsas e opiniões duvidosas e com a decadência da qualidade do conteúdo existente na internet, eu ajudo você!

Com o Criador De Cortes você pode criar cortes e thumbnails (protótipo) automaticamente a partir de algumas keywords 
## Instalação
Para instalar:
```
pip install CriadorDeCortes
```
## Como usar
Basta colocar as keywords no arquivo json:
``` 
"keywords":
    [
        "palavras", "polêmicas"
    ],
```
executar e colar o link do vídeo.
```
python criarCortes.py
```
## Versões 
v0.1 -- versão inicial
